package PRESENTACION;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {
    
    public static void main(String[] args) {
      
        Scanner sn = new Scanner(System.in);
        
        boolean salir = false;
        int opcion;
        
        while(!salir){
            
            System.out.println("MENU ADMISIONES");
            System.out.println("1. ADM - REGULARES");
            System.out.println("2. ADM - PRE UNIVERSITARIO");
            System.out.println("3. SALIR");
            
            try{
            
            System.out.println("ELEGIR LA OPCION DE SU PREFERENCIA");
            
            opcion = sn.nextInt();
            
            switch(opcion){
                case 1:
                    
                    System.out.println("Ingrese sus notas Icfes");
                    System.out.println("LECTURA CRITICA: ");
                    int lectura = sn.nextInt();
                    System.out.println("MATEMATICAS: ");
                    int matematicas = sn.nextInt();
                    System.out.println("SOCIALES: ");
                    int sociales = sn.nextInt();
                    System.out.println("NATURALES: ");
                    int naturales = sn.nextInt();
                    System.out.println("INGLES: ");
                    int ingles = sn.nextInt();
                        admRegulares(lectura,matematicas,sociales,naturales,ingles);
                    
                    break;
                    
                case 2:
                    
                    System.out.println("Ingrese su promedio del PreUniversitario");
                    System.out.println("PROMEDIO (10-50): ");
                    double promedio = sn.nextInt();
                    admPre(promedio);
                    
                    break;
                    
                case 3:
                    
                    salir=true;
                    
                    break; 
                    
                default:
                    System.out.println("----- OPCION INVALIDA -----");
                }
            
            }catch(InputMismatchException e){
                System.out.println("----- DEBE ELEGIR UN NUMERO -----");
                sn.next();
            }
        }
    }
    
    public static void admRegulares(int lec,int mate,int soc,int nat,int ing){
        
        double puntajeIcfes = (((lec*3+mate*3+soc*3+nat*3+ing*1)/13)*5);
        
        Scanner sc = new Scanner(System.in);
        int opcioncarr;
        boolean salir=false;
        
        while(!salir){
            
            System.out.println("SELECCIONE LA CARRERA");
            System.out.println("1. ADM. EMPRESAS");
            System.out.println("2. CONTADURIA");
            System.out.println("3. ECONOMIA");
            System.out.println("4. DERECHO");
            System.out.println("5. PSICOLOGIA");
            System.out.println("6. ING. AMBIENTAL");
            System.out.println("7. ING. SISTEMAS");
            System.out.println("8. ENFERMERIA");
            System.out.println("9. MICROBIOLOGIA");
            System.out.println("10. LIC. ESPAÑOL E INGLES");
            System.out.println("11. VOLVER");
            
            try{
            
            System.out.println("ELEGIR LA OPCION DE SU PREFERENCIA");
            
            opcioncarr = sc.nextInt();
            
            switch(opcioncarr){
                
                //ADM. EMPRESAS
                case 1:
                    
                    double ponderadoEmp = (lec*0.3)+(mate*0.3)+(soc*0.15)+(nat*0.1)+(ing*0.15);
        
                    if (ponderadoEmp>51){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoEmp);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                
                //CONTADURIA    
                case 2:
                    
                    double ponderadoCont = (lec*0.25)+(mate*0.35)+(soc*0.15)+(nat*0.1)+(ing*0.15);
        
                    if (ponderadoCont>53){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoCont);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                
                //ECONOMIA    
                case 3:
                    
                    double ponderadoEco = (lec*0.25)+(mate*0.35)+(soc*0.15)+(nat*0.1)+(ing*0.15);
        
                    if (ponderadoEco>37){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoEco);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                
                //DERECHO    
                case 4:
                    
                    double ponderadoDer = (lec*0.35)+(mate*0.1)+(soc*0.3)+(nat*0.1)+(ing*0.15);
        
                    if (ponderadoDer>60){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoDer);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                
                //PSICOLOGIA    
                case 5:
                    
                    double ponderadoPsi = (lec*0.35)+(mate*0.10)+(soc*0.30)+(nat*0.10)+(ing*0.15);
        
                    if (ponderadoPsi>63){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoPsi);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                
                //ING AMBIENTAL
                case 6:
                    
                    double ponderadoIngAmb = (lec*0.20)+(mate*0.25)+(soc*0.15)+(nat*0.25)+(ing*0.15);
        
                    if (ponderadoIngAmb>46){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoIngAmb);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                    
                //ING SISTEMAS
                case 7:
                    
                    double ponderadoIngSis = (lec*0.20)+(mate*0.30)+(soc*0.15)+(nat*0.20)+(ing*0.15);
        
                    if (ponderadoIngSis>56){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoIngSis);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                    
                //ENFERMERIA
                case 8:
                    
                    double ponderadoEnf = (lec*0.2)+(mate*0.2)+(soc*0.15)+(nat*0.25)+(ing*0.20);
        
                    if (ponderadoEnf>61){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoEnf);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                    
                //MICROBIOLOGIA
                case 9:
                    
                    double ponderadoMic = (lec*0.20)+(mate*0.15)+(soc*0.15)+(nat*0.30)+(ing*0.2);
        
                    if (ponderadoMic>53){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoMic);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;    
                
                //LIC. ESPAÑOL E INGLES                
                case 10:
                    
                    double ponderadoLicEI = (lec*0.4)+(mate*0.1)+(soc*0.15)+(nat*0.1)+(ing*0.25);
        
                    if (ponderadoLicEI>64){
            
                    System.out.println("Su puntaje CUMPLE los requisitos");
                    System.out.println("Su ponderado es "+ponderadoLicEI);
                
                    }else
            
                    System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
                    
                    break;
                
                //VOLVER
                case 11:
                    
                    salir=true;
                    
                    break;
                    
                default:
                    System.out.println("----- OPCION INVALIDA -----");
            }
            
        }catch(InputMismatchException e){
                System.out.println("----- DEBE ELEGIR UN NUMERO -----");
                sc.next();
        }
            
        }
    }
    
    public static void admCarrera(int lec,int mate,int soc,int nat,int ing){
        
        double ponderadoSist = (lec*0.2)+(mate*0.3)+(soc*0.15)+(nat*0.2)+(ing*0.15);
        
        if (ponderadoSist>56){
            System.out.println("Su puntaje CUMPLE los requisitos");
            System.out.println("Su ponderado es "+ponderadoSist);
        }else
            System.out.println("Su puntaje NO CUMPLE los requisitos minimos");
            System.out.println("Su ponderado es "+ponderadoSist);
            
        
    }
    
    public static void admPre(double promedio){
        
        if (promedio>=38){
            System.out.println("Su promedio CUMPLE los requisitos");
        }else
            System.out.println("Su promedio NO CUMPLE los requisitos minimos");
    }
}