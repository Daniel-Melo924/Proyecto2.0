package ENTIDADES;

public class PreUniversitario extends Admisiones{
    private double promedioPre;

    public PreUniversitario(String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);
    }

    public PreUniversitario(double promedioPre, String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);
        this.promedioPre = promedioPre;
    }

    public double getPromedioPre() {
        return promedioPre;
    }

    public void setPromedioPre(double promedioPre) {
        this.promedioPre = promedioPre;
    }
    
    
}
