package ENTIDADES;

public class Regulares extends Admisiones{
    private int documento;
    
    
    public Regulares(String nombre,String apellido,int edad,int documento){
        super(nombre,apellido,edad);
        this.documento = documento;
    }

    public int getDocumento() {
        return documento;
    }

    public void setDocumento(int documento) {
        this.documento = documento;
    }
    
        
}

